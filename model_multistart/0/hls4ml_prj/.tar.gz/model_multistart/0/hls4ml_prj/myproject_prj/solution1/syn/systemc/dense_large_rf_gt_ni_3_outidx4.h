// ==============================================================
// File generated on Tue Mar 02 22:54:53 -03 2021
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __dense_large_rf_gt_ni_3_outidx4_H__
#define __dense_large_rf_gt_ni_3_outidx4_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct dense_large_rf_gt_ni_3_outidx4_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 5;
  static const unsigned AddressRange = 3360;
  static const unsigned AddressWidth = 12;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(dense_large_rf_gt_ni_3_outidx4_ram) {
        for (unsigned i = 0; i < 120 ; i = i + 1) {
            ram[i] = "0b00000";
        }
        for (unsigned i = 120; i < 240 ; i = i + 1) {
            ram[i] = "0b00001";
        }
        for (unsigned i = 240; i < 360 ; i = i + 1) {
            ram[i] = "0b00010";
        }
        for (unsigned i = 360; i < 480 ; i = i + 1) {
            ram[i] = "0b00011";
        }
        for (unsigned i = 480; i < 600 ; i = i + 1) {
            ram[i] = "0b00100";
        }
        for (unsigned i = 600; i < 720 ; i = i + 1) {
            ram[i] = "0b00101";
        }
        for (unsigned i = 720; i < 840 ; i = i + 1) {
            ram[i] = "0b00110";
        }
        for (unsigned i = 840; i < 960 ; i = i + 1) {
            ram[i] = "0b00111";
        }
        for (unsigned i = 960; i < 1080 ; i = i + 1) {
            ram[i] = "0b01000";
        }
        for (unsigned i = 1080; i < 1200 ; i = i + 1) {
            ram[i] = "0b01001";
        }
        for (unsigned i = 1200; i < 1320 ; i = i + 1) {
            ram[i] = "0b01010";
        }
        for (unsigned i = 1320; i < 1440 ; i = i + 1) {
            ram[i] = "0b01011";
        }
        for (unsigned i = 1440; i < 1560 ; i = i + 1) {
            ram[i] = "0b01100";
        }
        for (unsigned i = 1560; i < 1680 ; i = i + 1) {
            ram[i] = "0b01101";
        }
        for (unsigned i = 1680; i < 1800 ; i = i + 1) {
            ram[i] = "0b01110";
        }
        for (unsigned i = 1800; i < 1920 ; i = i + 1) {
            ram[i] = "0b01111";
        }
        for (unsigned i = 1920; i < 2040 ; i = i + 1) {
            ram[i] = "0b10000";
        }
        for (unsigned i = 2040; i < 2160 ; i = i + 1) {
            ram[i] = "0b10001";
        }
        for (unsigned i = 2160; i < 2280 ; i = i + 1) {
            ram[i] = "0b10010";
        }
        for (unsigned i = 2280; i < 2400 ; i = i + 1) {
            ram[i] = "0b10011";
        }
        for (unsigned i = 2400; i < 2520 ; i = i + 1) {
            ram[i] = "0b10100";
        }
        for (unsigned i = 2520; i < 2640 ; i = i + 1) {
            ram[i] = "0b10101";
        }
        for (unsigned i = 2640; i < 2760 ; i = i + 1) {
            ram[i] = "0b10110";
        }
        for (unsigned i = 2760; i < 2880 ; i = i + 1) {
            ram[i] = "0b10111";
        }
        for (unsigned i = 2880; i < 3000 ; i = i + 1) {
            ram[i] = "0b11000";
        }
        for (unsigned i = 3000; i < 3120 ; i = i + 1) {
            ram[i] = "0b11001";
        }
        for (unsigned i = 3120; i < 3240 ; i = i + 1) {
            ram[i] = "0b11010";
        }
        for (unsigned i = 3240; i < 3360 ; i = i + 1) {
            ram[i] = "0b11011";
        }


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(dense_large_rf_gt_ni_3_outidx4) {


static const unsigned DataWidth = 5;
static const unsigned AddressRange = 3360;
static const unsigned AddressWidth = 12;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


dense_large_rf_gt_ni_3_outidx4_ram* meminst;


SC_CTOR(dense_large_rf_gt_ni_3_outidx4) {
meminst = new dense_large_rf_gt_ni_3_outidx4_ram("dense_large_rf_gt_ni_3_outidx4_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~dense_large_rf_gt_ni_3_outidx4() {
    delete meminst;
}


};//endmodule
#endif
