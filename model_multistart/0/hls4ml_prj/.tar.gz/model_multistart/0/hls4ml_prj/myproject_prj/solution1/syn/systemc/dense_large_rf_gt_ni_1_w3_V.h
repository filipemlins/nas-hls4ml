// ==============================================================
// File generated on Tue Mar 02 22:54:52 -03 2021
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __dense_large_rf_gt_ni_1_w3_V_H__
#define __dense_large_rf_gt_ni_1_w3_V_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct dense_large_rf_gt_ni_1_w3_V_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 31;
  static const unsigned AddressRange = 64;
  static const unsigned AddressWidth = 6;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(dense_large_rf_gt_ni_1_w3_V_ram) {
        ram[0] = "0b0101101100001111111011101101011";
        ram[1] = "0b1100111110110000000001001011001";
        ram[2] = "0b0011000111101111111101110100111";
        ram[3] = "0b1111001100110000000010100010011";
        ram[4] = "0b1011110100110000000101101000100";
        ram[5] = "0b1001011110011111111110110110110";
        ram[6] = "0b1001100001000111111011000010011";
        ram[7] = "0b1011011110000000000010101000001";
        ram[8] = "0b1101001010010000000001100101111";
        ram[9] = "0b1011101100000111111101011001110";
        ram[10] = "0b1010100011101111111010000111110";
        ram[11] = "0b1101101001000111111110110010001";
        ram[12] = "0b0000000000001000000001010011000";
        ram[13] = "0b1011110100010000000011001011010";
        ram[14] = "0b1011011000110111111111111110000";
        ram[15] = "0b0000101011111111111101011110011";
        ram[16] = "0b1011101000010000000100001011001";
        ram[17] = "0b1001011111001111111111011100000";
        ram[18] = "0b1110000000111000000100101011011";
        ram[19] = "0b1011000110011111111111111101101";
        ram[20] = "0b1010101100011111111110111111100";
        ram[21] = "0b0101101000111000000000101010001";
        ram[22] = "0b0011101110111000000011000111111";
        ram[23] = "0b0011000011110111111101010101011";
        ram[24] = "0b0011101101110111111011110110001";
        ram[25] = "0b0001110001110000000001001010000";
        ram[26] = "0b0010010000010000000101100010110";
        ram[27] = "0b0101110101111111111010001000100";
        ram[28] = "0b1101101010010000000001010001010";
        ram[29] = "0b0110100001110111111111011110110";
        ram[30] = "0b0010010111100000000101000101001";
        ram[31] = "0b0100011101100000000000110101111";
        ram[32] = "0b1001110111101000000001100110100";
        ram[33] = "0b1110111000101111111011111011101";
        ram[34] = "0b1001111111011000000100100101011";
        ram[35] = "0b1010011000000000000001011111010";
        ram[36] = "0b0001011111010111111110111101100";
        ram[37] = "0b1110011101000111111110101010010";
        ram[38] = "0b1111110101111111111110011100111";
        ram[39] = "0b0101010101100111111110000010101";
        ram[40] = "0b0101101011010111111101011110010";
        ram[41] = "0b1111001000001111111111011111001";
        ram[42] = "0b0010101010001000000000101001100";
        ram[43] = "0b1100000111001111111110010011111";
        ram[44] = "0b1100001101010000000011010100101";
        ram[45] = "0b1101000110010000000010101110111";
        ram[46] = "0b0010101010011000000101011111110";
        ram[47] = "0b1111110011011000000000010100011";
        ram[48] = "0b0001110001111000000010101010000";
        ram[49] = "0b1001101001110000000100000001011";
        ram[50] = "0b1011011010011111111101000000001";
        ram[51] = "0b0011010001010111111001100110101";
        ram[52] = "0b1101001011101000000011111110010";
        ram[53] = "0b1111001011011000000010100011101";
        ram[54] = "0b1101110001100111111001111110001";
        ram[55] = "0b0100010010001111111100011000110";
        ram[56] = "0b0110000110011111111111010011100";
        ram[57] = "0b1010100101011000000100001110111";
        ram[58] = "0b1111001010000000000001010010111";
        ram[59] = "0b1100111110100111111101101110010";
        ram[60] = "0b1110100001111000000100100011000";
        ram[61] = "0b1111000000010111111010100111101";
        ram[62] = "0b1110011111000000000101101111000";
        ram[63] = "0b0010101100111000000011110000010";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(dense_large_rf_gt_ni_1_w3_V) {


static const unsigned DataWidth = 31;
static const unsigned AddressRange = 64;
static const unsigned AddressWidth = 6;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


dense_large_rf_gt_ni_1_w3_V_ram* meminst;


SC_CTOR(dense_large_rf_gt_ni_1_w3_V) {
meminst = new dense_large_rf_gt_ni_1_w3_V_ram("dense_large_rf_gt_ni_1_w3_V_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~dense_large_rf_gt_ni_1_w3_V() {
    delete meminst;
}


};//endmodule
#endif
