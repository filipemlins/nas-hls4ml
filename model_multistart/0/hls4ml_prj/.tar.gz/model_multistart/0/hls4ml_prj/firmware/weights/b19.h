//Numpy array shape [1, 1, 1, 8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
model_default_t b19[8];
#else
model_default_t b19[8] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif
