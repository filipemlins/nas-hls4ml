//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B3_H_
#define B3_H_

#ifndef __SYNTHESIS__
model_default_t b3[8];
#else
model_default_t b3[8] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif
