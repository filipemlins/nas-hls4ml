//Numpy array shape [1, 10]
//Min 0.250000000000
//Max 0.250000000000
//Number of zeros 0

#ifndef S23_H_
#define S23_H_

#ifndef __SYNTHESIS__
model_default_t s23[10];
#else
model_default_t s23[10] = {0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000, 0.2500000000};
#endif

#endif
